var jsonData = [
    {
        "q" : "1. Index of an array in MATLAB start with",
        "opt1" : "0",
        "opt2" : "1",
        "opt3" : "Depends on the class of array",
        "answer" : "1"
    },
    {
        "q" : "2.What is the return type of angles function in MATLAB? ",
        "opt1" : " Radians",
        "opt2" : "Degrees",
        "opt3" : "Radians & Degrees",
        "answer" : " Radians"
    },
    {
        "q" : "3. What is use of abs function in Matlab? ",
        "opt1" : " returns magnitude of a number.",
        "opt2" : " returns power of number",
        "opt3" : " returns magnitude of a number.",
        "answer" : " returns magnitude of a number."
    },
    {
        "q" : "4. Which character is used to print new line in a fprintf statement? ",
        "opt1" : "\\nl",
        "opt2" : "\\nml",
        "opt3" : "\\n",
        "answer" : "\\n"
    },
    {
        "q" : "5. What is output of A = [1 0 2]; b = [3 0 7]; c=a.*b;  ",
        "opt1" : "[2 0 21]",
        "opt2" : "[3 0 14]",
        "opt3" : "[7 0 3]",
        "answer" : "[3 0 14]"
    },
    {
        "q" : "6. Which class is used in Matlab to store the complex number?  ",
        "opt1" : " character",
        "opt2" : " symbolic",
        "opt3" : " array",
        "answer" : " symbolic"
    },
    {
        "q" : "7. Which command clears all data and variables stored in memory?    ",
        "opt1" : " clear",
        "opt2" : "clc",
        "opt3" : "delete",
        "answer" : " clear"
    },
    {
        "q" : "8. Which of the following command lists the current variable in Matlab? ",
        "opt1" : "who",
        "opt2" : "Date",
        "opt3" : "Type",
        "answer" : "who"
    },
    {
        "q" : "9. Keys combition used to stop execution of a command in MATLAB?  ",
        "opt1" : " ctrl+b",
        "opt2" : " ctrl+s",
        "opt3" : " ctrl+c",
        "answer" : " ctrl+c"
    },
    {
        "q" : "10. What will be the output of atan2(-1,1) in Matlab? ",
        "opt1" : " Error ",
        "opt2" : " 0.7854 ",
        "opt3" : " pi/4 ",
        "answer" : "  0.7854"
    }
];