var jsonData = [
    {
        "q" : "1. Why would a hacker use a proxy server? ",
        "opt1" : "To hide malicious activity on the network.",
        "opt2" : "To create a ghost server on the network.",
        "opt3" : " To obtain a remote access connection.",
        "answer" : "To hide malicious activity on the network."
    },
    {
        "q" : "2. Which ports should be blocked to prevent null session enumeration?",
        "opt1" : "Ports 136 and 139",
        "opt2" : "Ports 135 and 139",
        "opt3" : " Ports 135 and 136",
        "answer" : "Ports 135 and 139"
    },
    {
        "q" : "3.  What type of attack uses a fraudulent server with a relay address?",
        "opt1" : "SMB",
        "opt2" : "MITM",
        "opt3" : "NetBIOS",
        "answer" : "MITM"
    },
    {
        "q" : "4. What port is used to connect to the Active Directory in Windows 2000? ",
        "opt1" : "80",
        "opt2" : "139",
        "opt3" : " 389",
        "answer" : " 389"
    },
    {
        "q" : "5. To hide information inside a picture, what technology is used?",
        "opt1" : "Steganography",
        "opt2" : "Image Rendering",
        "opt3" : "Bitmapping",
        "answer" : "Steganography"
    },
    {
        "q" : "6. Which phase of hacking performs actual attack on a network or system?",
        "opt1" : "Gaining Access",
        "opt2" : " Maintaining Access",
        "opt3" : "Scanning",
        "answer" : "Gaining Access "
    },
    {
        "q" : "7. Which is not a typical characteristic of an ethical hacker?  ",
        "opt1" : "Excellent knowledge of Windows.",
        "opt2" : "Has the highest level of security for the organization",
        "opt3" : "Patience, persistence and perseverance",
        "answer" : "Has the highest level of security for the organization"
    },
    {
        "q" : "8. What is the proper command to perform Nmap XMAS scan every 15secs?",
        "opt1" : "nmap -sX -polite",
        "opt2" : "nmap -sX -sneaky",
        "opt3" : " nmap -sX -aggressive",
        "answer" : "nmap -sX -sneaky"
    },
    {
        "q" : "9. What is the purpose of a Denial of Service attack? ",
        "opt1" : "To shutdown services by turning them off",
        "opt2" : "To overload a system so it is no longer operational",
        "opt3" : "To execute a Trojan on a system",
        "answer" : "To overload a system so it is no longer operational"
    },
    {
        "q" : "10. What is the sequence of a TCP connection?",
        "opt1" : "SYN-ACK-FIN ",
        "opt2" : "SYN-SYN-ACK ",
        "opt3" : "SYN-SYN ACK-ACK ",
        "answer" : "SYN-SYN ACK-ACK "
    }
];