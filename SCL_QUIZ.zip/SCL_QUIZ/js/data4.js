var jsonData = [
    {
        "q" : "1. PCBs should be fabricated with _____ layers",
        "opt1" : "Odd Number of",
        "opt2" : "Even Number of",
        "opt3" : "Any Number of",
        "answer" : "Even Number of"
    },
    {
        "q" : "2. The declaration of Vias-In-Pads is determined in the",
        "opt1" : " Assembly Notes",
        "opt2" : "Fabrication Notes",
        "opt3" : "Fabrication Files",
        "answer" : "Fabrication Notes"
    },
    {
        "q" : "3. The grid used in a PCB layout tool should be",
        "opt1" : "In metric (mm)",
        "opt2" : "Both A and B interchangeably",
        "opt3" : "Either A or B",
        "answer" : "Either A or B"
    },
    {
        "q" : "4. The biggest factor when it comes to impedance is ",
        "opt1" : "The physical aspects of the board",
        "opt2" : "Clock speed of the board crystal",
        "opt3" : "The voltage level",
        "answer" : "The physical aspects of the board"
    },
    {
        "q" : "5. The solder paste files are generally produced",
        "opt1" : "In the fabrication files",
        "opt2" : "In the assembly file",
        "opt3" : "Manually drawn",
        "answer" : "In the fabrication files"
    },
    {
        "q" : "6. When is the earliest time one should communicate the bill of materials: ",
        "opt1" : "After fabrication has been started",
        "opt2" : "After the boards have been fabricated",
        "opt3" : "When the schematics are completed",
        "answer" : "When the schematics are completed "
    },
    {
        "q" : "7. When writing a requirement ",
        "opt1" : "The use of the word “and” is okay",
        "opt2" : "The use of the word “or” is okay",
        "opt3" : "Both of the above",
        "answer" : "The use of the word “and” is okay"
    },
    {
        "q" : "8. The use of 3D component models in the PCB layout can assist with ",
        "opt1" : "Component clearance",
        "opt2" : "Electrical clearance",
        "opt3" : "All of the above",
        "answer" : "Component clearance"
    },
    {
        "q" : "9. Silk Screens",
        "opt1" : "Are not required for every component",
        "opt2" : "Are not necessary for production boards",
        "opt3" : "All of the above",
        "answer" : "All of the above"
    },
    {
        "q" : "10. Which must be provided to fabricator to program drilling equipment?",
        "opt1" : "Drill Plot ",
        "opt2" : "Drill Drawing ",
        "opt3" : "NC Drill file ",
        "answer" : "NC Drill file"
    }
];