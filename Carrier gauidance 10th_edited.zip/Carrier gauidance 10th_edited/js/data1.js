var jsonData = [
    {
        "q" : "1. Which gas is needed for photosynthesis?",
        "opt1" : "Oxygen",
        "opt2" : "Carbon dioxide",
        "opt3" : "Carbon monoxide",
        "answer" : "Carbon dioxide"
    },
    {
        "q" : "2. Tomatoes in a greenhouse grow faster if the carbon dioxide concentration is increased. This shows that: ",
        "opt1" : " Temperature must have been a limiting factor",
        "opt2" : "Carbon dioxide concentration must have been a limiting factor",
        "opt3" : "Light intensity must have been a limiting factor",
        "answer" : "Carbon dioxide concentration must have been a limiting factor"
    },
    {
        "q" : "3. The plant cells that can develop into any type of tissue are called: ",
        "opt1" : "Meristems",
        "opt2" : "Xylems",
        "opt3" : "Embryonic stem cells",
        "answer" : "Meristems"
    },
    {
        "q" : "4. Chromosomes move toward opposite ends of the cell during: ",
        "opt1" : "Anaphase",
        "opt2" : "Metaphase",
        "opt3" : "Telophase",
        "answer" : "Anaphase"
    },
    {
        "q" : "5.Which of the following are energy foods?",
        "opt1" : " Carbohydrates and fats",
        "opt2" : "Vitamins and minerals",
        "opt3" : "Proteins and mineral salts",
        "answer" : " Carbohydrates and fats"
    },
    {
        "q" : "6. In amoeba, food is digested in the: ",
        "opt1" : "food vacuole",
        "opt2" : " pseudopodia",
        "opt3" : " chloroplast",
        "answer" : "food vacuole"
    },
    {
        "q" : "7. Which region of the alimentary canal absorbs the digested food?",
        "opt1" : " Large intestine",
        "opt2" : "Small intestine",
        "opt3" : "Stomach",
        "answer" : "Small intestine"
    },
    {
        "q" : "8. What are the products obtained by anaerobic respiration in plants?",
        "opt1" : " Ethanol + Carbon dioxide + Energy",
        "opt2" : "Carbon dioxide + Water + Energy",
        "opt3" : "Lactic acid + Energy",
        "answer" : " Ethanol + Carbon dioxide + Energy"
    },
    {
        "q" : "9.  A blood vessel which pumps the blood from the heart to the entire body:",
        "opt1" : " artery",
        "opt2" : "capillary",
        "opt3" : " Vein",
        "answer" : " artery"
    },
    {
        "q" : "10. Which of the following are exothermic processes?",
        "opt1" : "Dilution of an acid ",
        "opt2" : "Reaction of water with quick lime",
        "opt3" : "Burning of coal",
        "answer" : "Reaction of water with quick lime"
    },
    {
        "q" : "11. Are you good at Maths?",
        "opt1" : "Yes",
        "opt2" : "No",
        "opt3" : " May be",
        "answer" : "Yes"
    },
    {
        "q" : "12. Are you intrested to work in IT or medical feild?",
        "opt1" : "Yes ",
        "opt2" : "No",
        "opt3" : " May be",
        "answer" : "Yes"
    }
];