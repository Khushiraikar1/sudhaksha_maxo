var jsonData = [
    {
        "q" : "1.'average income’ is.",
        "opt1" : "total income of the country.",
        "opt2" : " income of only employed people.",
        "opt3" : "income is the same as per capita income.",
        "answer" : "income is the same as per capita income."
    },
    {
        "q" : "2. An MNC is a company that owns or controls production in",
        "opt1" : "one country ",
        "opt2" : "only developing countries",
        "opt3" : " more than one country",
        "answer" : " more than one country"
    },
    {
        "q" : "3. The forest cover in our country has recently increased due to:",
        "opt1" : "Increase in natural forest growth",
        "opt2" : "Plantation by different agencies",
        "opt3" : "Increase in net sown area",
        "answer" : "Plantation by different agencies"
    },
    {
        "q" : "4. Which one of the following is not responsible for the decline in India’s biodiversity?",
        "opt1" : "Hunting and poaching",
        "opt2" : "Afforestation",
        "opt3" : "Forest fire",
        "answer" : "Afforestation"
    },
    {
        "q" : "5. What would be the most promising source of energy fifty years from now and why?",
        "opt1" : "Petroleum energy, because it is obtained from fossil fuels. ",
        "opt2" : "Solar energy, because it is not exhaustible.",
        "opt3" : "Coal based energy, because it is pollution- free.",
        "answer" : "Solar energy, because it is not exhaustible."
    },
    {
        "q" : "6. Which organisation supports liberalisation of foreign trade and investments in India?",
        "opt1" : "International Labour Organisation (ILO)",
        "opt2" : "World Trade Organisation (WTO)",
        "opt3" : "International Monetary Fund (IMF)",
        "answer" : "World Trade Organisation (WTO)"
    },
    {
        "q" : "7. The processing of raw material into more valuable products falls under the category of",
        "opt1" : "Primary activities ",
        "opt2" : "Secondary activities",
        "opt3" : "Tertiary activities",
        "answer" : "Secondary activities"
    },
    {
        "q" : "8. Name the first industrial country in the world: ",
        "opt1" : " Japan",
        "opt2" : "Germany ",
        "opt3" : "France ",
        "answer" : "Japan "
    },
    {
        "q" : "9. We need to conserve our forests and wildlife:",
        "opt1" : "for maintenance of aquatic biodiversity ",
        "opt2" : "so that we are able to over-extract plant and animal species ",
        "opt3" : "to preserve the ecological diversity",
        "answer" : "so that we are able to over-extract plant and animal species "
    },
    {
        "q" : "10. Which of the following industries have been hard hit by foreign competition? ",
        "opt1" : "Dairy products",
        "opt2" : " Leather industry",
        "opt3" : " Cloth industry",
        "answer" : "Dairy products "
    },
    {
        "q" : "11. Are you good at Economics and Business studies?",
        "opt1" : "Yes",
        "opt2" : "No",
        "opt3" : " May be",
        "answer" : "Yes"
    },
    {
        "q" : "12. Are you intrested to do bank jobs or CA?",
        "opt1" : "Yes ",
        "opt2" : "No",
        "opt3" : " May be",
        "answer" : "Yes"
    }
];