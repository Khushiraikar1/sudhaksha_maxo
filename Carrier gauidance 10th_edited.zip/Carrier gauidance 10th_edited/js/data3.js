var jsonData = [
    {
        "q" : "1. Sociology emerged in ",
        "opt1" : " Europe",
        "opt2" : "Africa",
        "opt3" : "Asia",
        "answer" : "Europe"
    },
    {
        "q" : "2. Who set up the ‘Oudh Kisan Sabha’?",
        "opt1" : " Jawahar Lai Nehru and Baba Ramchandra",
        "opt2" : "Jawaharlal Nehru and Shaukat Ali",
        "opt3" : "Mahatma Gandhi",
        "answer" : "Jawahar Lai Nehru and Baba Ramchandra"
    },
    {
        "q" : "3. Psychology is defined as the scientific study of:",
        "opt1" : "people and things",
        "opt2" : "perception and religion",
        "opt3" : "mind and behaviour",
        "answer" : "mind and behaviour"
    },
    {
        "q" : "4.  What does satyagraha mean?",
        "opt1" : " use of physical force to inflict pain while fighting.",
        "opt2" : "does not inflict pain, it is a : non-violent method of fighting against oppression.",
        "opt3" : " means passive resistance and is a weapon of the weak.",
        "answer" : "does not inflict pain, it is a : non-violent method of fighting against oppression."
    },
    {
        "q" : "5.There are two types of definition of society. These are-",
        "opt1" : "Structural and evolutionary",
        "opt2" : "Functional and structural",
        "opt3" : " Structural and interactional",
        "answer" : "Functional and structural"
    },
    {
        "q" : "6. Who was proclaimed the emperor of Germany in 1871?",
        "opt1" : "Kaiser William I of Prussia",
        "opt2" : "Victor Emmanuel II",
        "opt3" : "Count Cavour",
        "answer" : "Kaiser William I of Prussia"
    },
    {
        "q" : "7.   According to the text, the lower level of explanation corresponds to ___ processes. ",
        "opt1" : "social",
        "opt2" : "cultural",
        "opt3" : "biological",
        "answer" : "biological"
    },
    {
        "q" : "8.  The basis of slave system is always? ",
        "opt1" : "Social need ",
        "opt2" : "Political ",
        "opt3" : " Economic ",
        "answer" : " Economic "
    },
    {
        "q" : "9. Who formed the ‘Swaraj Party’ within the Congress?",
        "opt1" : "Jawahar Lai Nehru and Subhas Chandra Bose ",
        "opt2" : "C.R. Das and Motilal Nehru ",
        "opt3" : "Jawahar Lai Nehru and Motilal Nehru ",
        "answer" : " C.R. Das and Motilal Nehru"
    },
    {
        "q" : "10. ______ is the belief that the mind is fundamentally different from the body.",
        "opt1" : "dualism",
        "opt2" : "mindism ",
        "opt3" : "centralism ",
        "answer" : "dualism "
    },
    {
        "q" : "11. Do you think you are creative?",
        "opt1" : "Yes",
        "opt2" : "No",
        "opt3" : " May be",
        "answer" : "Yes"
    },
    {
        "q" : "12. Are you intrested in teacher lecturer or artist kind of jobs?",
        "opt1" : "Yes ",
        "opt2" : "No",
        "opt3" : " May be",
        "answer" : "Yes"
    }
];