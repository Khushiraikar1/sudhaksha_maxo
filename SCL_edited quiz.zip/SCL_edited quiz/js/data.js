var jsonData = [
    {
        "q" : "1. Autocad was developed by ______.",
        "opt1" : "Microsoft Corp.",
        "opt2" : "Apple Inc.",
        "opt3" : "Autodesk Inc.",
        "answer" : "Autodesk Inc."
    },
    {
        "q" : "2. Which workspaces are available in AutoCAD?",
        "opt1" : "3D modelling.",
        "opt2" : "Drafting and Annotation.",
        "opt3" : "All of the above.",
        "answer" : "All of the above."
    },
    {
        "q" : "3. Which is widely used to measure flood variability?",
        "opt1" : " FFMI",
        "opt2" : "FI",
        "opt3" : "FFI",
        "answer" : " FFMI"
    },
    {
        "q" : "4. By which comand,you a rectangle can drawn?",
        "opt1" : "POL",
        "opt2" : " REC",
        "opt3" : "CO",
        "answer" : " REC"
    },
    {
        "q" : "5. Which command used to create multiple viewports? ",
        "opt1" : "GROUP",
        "opt2" : "VPORTS",
        "opt3" : "EATTEDIT",
        "answer" : "VPORTS"
    },
    {
        "q" : "6. What does AutoCAD stands for?  ",
        "opt1" : "Automatical Computer Aided Design",
        "opt2" : "Automated Computer Application Design",
        "opt3" : "Automatic Computer Aided Data",
        "answer" : "Automatical Computer Aided Design"
    },
    {
        "q" : "7. How many units are available in AutoCAD?   ",
        "opt1" : "3",
        "opt2" : "5",
        "opt3" : "7",
        "answer" : "5"
    },
    {
        "q" : "8. ___ key automatically activates the O snap feature.",
        "opt1" : "F3",
        "opt2" : "F1",
        "opt3" : "F2",
        "answer" : "F3"
    },
    {
        "q" : "9. The scale command can be accessed by typing ____ ",
        "opt1" : "S",
        "opt2" : "SC",
        "opt3" : "SL",
        "answer" : "SC"
    },
    {
        "q" : "10. Which state grid is use to design perspective?",
        "opt1" : " Isometric",
        "opt2" : " Pro-Optic",
        "opt3" : "Parametric",
        "answer" : " Isometric"
    }
];