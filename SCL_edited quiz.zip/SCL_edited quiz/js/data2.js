var jsonData = [
    {
        "q" : "1.The technology used to distribute service requests to resources referred as: ",
        "opt1" : "Load scheduling",
        "opt2" : "Load balancing",
        "opt3" : "Load performing",
        "answer" : "Load balancing"
    },
    {
        "q" : "2.Which software can be used to implement load balancing? ",
        "opt1" : "Apache mod_proxy_balancer",
        "opt2" : "F6’s BigIP",
        "opt3" : "Apache mod_balancer",
        "answer" : "Apache mod_proxy_balancer"
    },
    {
        "q" : "3. Which of the following is a more sophisticated load balancer?  ",
        "opt1" : "Rack server managers",
        "opt2" : "Workload managers",
        "opt3" : "Workspace managers",
        "answer" : "Workload managers"
    },
    {
        "q" : "4.  Which service provider provides the least amount of built-in security?",
        "opt1" : "PaaS",
        "opt2" : "SaaS",
        "opt3" : "IaaS",
        "answer" : "IaaS"
    },
    {
        "q" : "5. Which of the following is the operational domain of CSA? ",
        "opt1" : "Flexibility",
        "opt2" : "Portability and interoperability",
        "opt3" : "Scalability",
        "answer" : "Portability and interoperability"
    },
    {
        "q" : "6. Which is considered an essential element in cloud computing by CSA? ",
        "opt1" : "Multi-tenancy ",
        "opt2" : "Identity and access management ",
        "opt3" : "Virtualization ",
        "answer" : "Multi-tenancy "
    },
    {
        "q" : "7. Which is used for Web performance management and load testing? ",
        "opt1" : "VMware Hyperic ",
        "opt2" : "Tapinsystems ",
        "opt3" : " Web metrics",
        "answer" : "Web metrics "
    },
    {
        "q" : "8. Which type of virtualization is also characteristic of cloud computing?  ",
        "opt1" : "Storage",
        "opt2" : "Application",
        "opt3" : "All of the Above",
        "answer" : "All of the Above"
    },
    {
        "q" : "9. Which area of cloud computing is uniquely troublesome? ",
        "opt1" : "Auditing ",
        "opt2" : "Data Integrity ",
        "opt3" : " All of the above",
        "answer" : "All of the above "
    },
    {
        "q" : "10. A ______ is a combination load balancer and application server.  ",
        "opt1" : "ABC  ",
        "opt2" : " ACD ",
        "opt3" : " ADC ",
        "answer" : " ADC "
    }
];